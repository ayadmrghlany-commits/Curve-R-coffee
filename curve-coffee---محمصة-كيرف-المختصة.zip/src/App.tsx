/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useEffect } from 'react';
import { 
  ShoppingCart, Menu, X, ChevronRight, 
  Trash2, Plus, Minus, 
  Award, Truck, ShieldCheck, Instagram, Twitter,
  Sun, Moon, Globe
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Translations ---
const t = {
  ar: {
    title: "كيرف كوفي",
    subtitle: "محمصة مختصة سعودية",
    heroTitle: "اكتشف منحنى النكهة",
    heroItalic: "المثالي",
    heroDesc: "نحن لا نحمص القهوة فقط، بل نعتني بكل حبة لنقدم لك تجربة عطرية لا تُنسى من قلب مزارع إثيوبيا وكولومبيا.",
    shopNow: "تسوق الآن",
    ourStory: "اكتشف قصتنا",
    features: [
      { title: "جودة مختصة", desc: "محاصيل منتقاة من أفضل المزارع العالمية" },
      { title: "توصيل سريع", desc: "نصلك أينما كنت في أسرع وقت ممكن" },
      { title: "دفع آمن", desc: "خيارات دفع متنوعة وآمنة تماماً" }
    ],
    selectedCrops: "محاصيلنا المختارة",
    viewAll: "عرض جميع المنتجات",
    store: "المتجر الإلكتروني",
    all: "الكل",
    crops: "محاصيل",
    tools: "أدوات",
    portable: "أظرف ترشيح",
    aboutTitle: "المنحنى الذي يصنع الفرق",
    aboutDesc: "نحن نؤمن أن القهوة ليست مجرد مشروب صباحي، بل هي علم وفن. اخترنا اسم كيرف ليرمز إلى منحنى التحميص المثالي.",
    missionTitle: "رسالتنا",
    missionDesc: "تمكين عشاق القهوة من الاستمتاع بأعلى معايير الجودة.",
    visionTitle: "رؤيتنا",
    visionDesc: "أن نكون الوجهة الأولى للقهوة المختصة في المنطقة العربية.",
    cartTitle: "سلة التسوق",
    emptyCart: "سلتك فارغة، ابدأ بإضافة بعض القهوة!",
    continueShopping: "استكمال التسوق",
    subtotal: "المجموع الفرعي",
    shipping: "الشحن",
    total: "الإجمالي العام",
    checkout: "إتمام الطلب عبر الواتساب",
    currency: "ر.س",
    details: "التفاصيل",
    addToCart: "إضافة للسلة",
    footerDesc: "وجهتكم الأولى لكل ما يخص عالم القهوة المختصة.",
    location: "الرياض، المملكة العربية السعودية",
    nav: { home: "الرئيسية", shop: "المتجر", about: "عن المحمصة" }
  },
  en: {
    title: "Curve Coffee",
    subtitle: "Saudi Specialty Roastery",
    heroTitle: "Discover the Flavor Curve",
    heroItalic: "Perfected",
    heroDesc: "We don't just roast coffee; we care for every bean to bring you an unforgettable aromatic experience from Ethiopia and Colombia.",
    shopNow: "Shop Now",
    ourStory: "Our Story",
    features: [
      { title: "Specialty Quality", desc: "Handpicked crops from the world's finest farms" },
      { title: "Fast Delivery", desc: "Reaching you wherever you are as fast as possible" },
      { title: "Secure Payment", desc: "Diverse and completely secure payment options" }
    ],
    selectedCrops: "Selected Crops",
    viewAll: "View All Products",
    store: "Online Store",
    all: "All",
    crops: "Crops",
    tools: "Tools",
    portable: "Portable Filters",
    aboutTitle: "The Curve That Makes a Difference",
    aboutDesc: "We believe coffee isn't just a morning drink; it's a science and an art. We chose 'Curve' to represent the perfect roasting curve.",
    missionTitle: "Our Mission",
    missionDesc: "Empowering coffee lovers to enjoy the highest quality standards.",
    visionTitle: "Our Vision",
    visionDesc: "To be the leading destination for specialty coffee in the Arab region.",
    cartTitle: "Shopping Cart",
    emptyCart: "Your cart is empty, start adding some coffee!",
    continueShopping: "Continue Shopping",
    subtotal: "Subtotal",
    shipping: "Shipping",
    total: "Grand Total",
    checkout: "Checkout via WhatsApp",
    currency: "SAR",
    details: "Details",
    addToCart: "Add to Cart",
    footerDesc: "Your premier destination for everything specialty coffee.",
    location: "Riyadh, Saudi Arabia",
    nav: { home: "Home", shop: "Shop", about: "About Us" }
  }
};

const PRODUCTS = [
  {
    id: 1,
    name: { ar: "جبل هادا - منتج مميز", en: "Jabal Hada - Special Edition" },
    price: 232.00,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://media.zid.store/a411588d-f618-4b28-ae07-e78b9f222c20/ba987a94-b0cd-439e-9b5b-a522af702e6d.png",
    notes: { ar: "نكهة معقدة، فاكهية، قوام ممتلئ", en: "Complex flavor, Fruity, Full body" },
    variety: "Specialty",
    process: { ar: "معالجة خاصة", en: "Special Process" },
    altitude: "2100m",
    description: { ar: "محصول جبل هادا المميز بتجربة نكهة استثنائية.", en: "Special Jabal Hada crop offering an exceptional flavor experience." }
  },
  {
    id: 2,
    name: { ar: "ديكاف - منزوعة الكافيين", en: "Decaf" },
    price: 53.00,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1580915411954-282cb1b0d780?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "نكهة متوازنة، شوكولاتة ناعمة", en: "Balanced flavor, Smooth chocolate" },
    variety: "Mixed",
    process: { ar: "منزوعة الكافيين", en: "Decaffeinated" },
    altitude: "1500m",
    description: { ar: "قهوة لذيذة بدون كافيين.", en: "Delicious coffee without the caffeine." }
  },
  {
    id: 3,
    name: { ar: "هامبيلا - أثيوبيا", en: "Hambela - Ethiopia" },
    price: 65.50,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "ياسمين، عسل، فواكه استوائية", en: "Jasmine, Honey, Tropical fruits" },
    variety: "Heirloom",
    process: { ar: "مجففة", en: "Natural" },
    altitude: "2000m",
    description: { ar: "محصول هامبيلا الفخم من مرتفعات أثيوبيا.", en: "Premium Hambela crop from the Ethiopian highlands." }
  },
  {
    id: 4,
    name: { ar: "أثيوبيا - أظرف", en: "Ethiopia - Drip Bags" },
    price: 32.00,
    category: { ar: "أظرف ترشيح", en: "Portable Filters" },
    image: "https://images.unsplash.com/photo-1524350303351-80857d4aef84?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "حمضية خفيفة، إيحاءات زهرية", en: "Light acidity, Floral notes" },
    variety: "Various",
    process: { ar: "موفرة", en: "Convenient" },
    altitude: "1800m",
    description: { ar: "أظرف قهوة أثيوبية سريعة التحضير.", en: "Quick-brew Ethiopian drip bags." }
  },
  {
    id: 5,
    name: { ar: "البرازيل - أظرف", en: "Brazil - Drip Bags" },
    price: 32.00,
    category: { ar: "أظرف ترشيح", en: "Portable Filters" },
    image: "https://images.unsplash.com/photo-1559056199-d561a0ac8b55?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "جوز، كاكاو، حمضية منخفضة", en: "Nutty, Cocoa, Low Acidity" },
    variety: "Bourbon",
    process: { ar: "موفرة", en: "Convenient" },
    altitude: "1100m",
    description: { ar: "أظرف قهوة برازيلية متوازنة لرحلاتك.", en: "Balanced Brazilian drip bags for your travels." }
  },
  {
    id: 6,
    name: { ar: "بيرو - أظرف", en: "Peru - Drip Bags" },
    price: 32.00,
    category: { ar: "أظرف ترشيح", en: "Portable Filters" },
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "شوكولاتة داكنة، حمضية تفاح", en: "Dark chocolate, Apple acidity" },
    variety: "Typica",
    process: { ar: "موفرة", en: "Convenient" },
    altitude: "1600m",
    description: { ar: "أظرف قهوة بيرو بنكهة غنية أينما كنت.", en: "Rich flavored Peru drip bags anywhere you are." }
  },
  {
    id: 7,
    name: { ar: "كولومبيا - أظرف", en: "Colombia - Drip Bags" },
    price: 32.00,
    category: { ar: "أظرف ترشيح", en: "Portable Filters" },
    image: "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "كراميل، شوكولاتة ناعمة", en: "Caramel, Smooth chocolate" },
    variety: "Caturra",
    process: { ar: "موفرة", en: "Convenient" },
    altitude: "1700m",
    description: { ar: "أظرف القهوة الكولومبية التقليدية سريعة التحضير.", en: "Fast-brew traditional Colombian drip bags." }
  },
  {
    id: 8,
    name: { ar: "كونجو - أثيوبيا", en: "Congo - Ethiopia" },
    price: 94.88,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1497933321110-3882776c5b05?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "مزيج فريد، فواكه غنية", en: "Unique blend, Rich fruits" },
    variety: "Special Blend",
    process: { ar: "مختلطة", en: "Mixed" },
    altitude: "1900m",
    description: { ar: "مزيج يجمع بين عراقة أثيوبيا وقوة الكونغو.", en: "A blend combining Ethiopian tradition and Congolese strength." }
  },
  {
    id: 9,
    name: { ar: "قايا اندونيسيا", en: "Gayo Indonesia" },
    price: 57.00,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1518057111178-0438675c2b4d?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "توابل دافئة، ترابية ناعمة", en: "Warm spices, Earthy smooth" },
    variety: "Sumatra Gayo",
    process: { ar: "تقشير رطب", en: "Wet Hulled" },
    altitude: "1400m",
    description: { ar: "قهوة اندونيسية كلاسيكية من منطقة قايا.", en: "Classic Indonesian coffee from the Gayo region." }
  },
  {
    id: 10,
    name: { ar: "ديمانتي - كولومبيا", en: "Diamante - Colombia" },
    price: 56.93,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1498804103079-a6351b050096?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "أزهار، ليمون، سكر بني", en: "Floral, Lemon, Brown sugar" },
    variety: "Castillo",
    process: { ar: "مغسولة", en: "Washed" },
    altitude: "1850m",
    description: { ar: "محصول ديمانتي الفاخر بنكهات مشرقة.", en: "Premium Diamante crop with bright flavors." }
  },
  {
    id: 11,
    name: { ar: "دايموند - البرازيلي", en: "Diamond - Brazil" },
    price: 43.00,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1447933601403-0c6688de566e?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "كراميل، جوز محمص", en: "Caramel, Roasted nuts" },
    variety: "Santos",
    process: { ar: "مجففة", en: "Natural" },
    altitude: "1150m",
    description: { ar: "قهوة برازيلية ذات قوام حريري.", en: "Brazilian coffee with a silky body." }
  },
  {
    id: 12,
    name: { ar: "قهوة سعودية", en: "Saudi Coffee" },
    price: 45.00,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1541167760496-1628856ab772?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "هيل، زعفران، جودة مختصة", en: "Cardamom, Saffron, Specialty quality" },
    variety: "Traditional Blend",
    process: { ar: "محمصة فاتحة", en: "Light Roast" },
    altitude: "1400m",
    description: { ar: "القهوة السعودية الأصيلة بمفهوم مختص.", en: "Authentic Saudi coffee with a specialty concept." }
  },
  {
    id: 13,
    name: { ar: "بيلويا - أثيوبيا", en: "Beloia - Ethiopia" },
    price: 65.50,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "توت أسود، شوكولاتة، حمضية ناعمة", en: "Blackberry, Chocolate, Soft acidity" },
    variety: "Welo",
    process: { ar: "مجففة", en: "Natural" },
    altitude: "1950m",
    description: { ar: "محصول بيلويا الأثيوبي الغني بالنكهات.", en: "Richly flavored Ethiopian Beloia crop." }
  },
  {
    id: 14,
    name: { ar: "بيرياس - بيرو", en: "Perias - Peru" },
    price: 42.70,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "عسل، كراميل، برتقال", en: "Honey, Caramel, Orange" },
    variety: "Bourbon",
    process: { ar: "مغسولة", en: "Washed" },
    altitude: "1650m",
    description: { ar: "محصول بيرياس من بيرو بحلاوة طبيعية.", en: "Perias crop from Peru with natural sweetness." }
  },
  {
    id: 15,
    name: { ar: "أكسيلسو - كولومبيا", en: "Excelso - Colombia" },
    price: 40.25,
    category: { ar: "محاصيل", en: "Crops" },
    image: "https://images.unsplash.com/photo-1580915411954-282cb1b0d780?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "خوخ، فواكه حمراء، سكر", en: "Peach, Red fruits, Sugary" },
    variety: "Various",
    process: { ar: "مغسولة", en: "Washed" },
    altitude: "1600m",
    description: { ar: "درجة أكسيلسو الفاخرة من كولومبيا.", en: "Premium Excelso grade from Colombia." }
  },
  {
    id: 16,
    name: { ar: "طقم V60 سيراميك", en: "Ceramic V60 Set" },
    price: 120,
    category: { ar: "أدوات", en: "Tools" },
    image: "https://images.unsplash.com/photo-1544787210-2827255cdd6c?auto=format&fit=crop&q=80&w=400",
    notes: { ar: "طقم متكامل لتحضير القهوة المقطرة.", en: "Complete set for manual pour-over coffee." },
    description: { ar: "طقم متكامل لتحضير القهوة المقطرة.", en: "Complete set for manual pour-over coffee." }
  }
];

const ProductCard = ({ p, lang, theme, currency, addToCart }: any) => (
  <div key={p.id} className={`p-4 rounded-[2rem] border group transition-all duration-300 ${theme === 'dark' ? 'bg-zinc-900/40 border-zinc-800 hover:border-amber-500/40' : 'bg-white border-zinc-200 hover:border-amber-300 shadow-sm'}`}>
    <div className="h-48 rounded-2xl overflow-hidden relative mb-4">
      <img src={p.image} className="w-full h-full object-cover group-hover:scale-110 transition duration-700" alt="" />
    </div>
    <h3 className="text-lg font-bold mb-1">{p.name[lang]}</h3>
    <p className={`text-xs mb-4 ${theme === 'dark' ? 'text-zinc-500' : 'text-zinc-400'}`}>{p.notes[lang]}</p>
    <div className="flex justify-between items-center">
      <span className="text-amber-500 font-black">{p.price} {currency}</span>
      <button onClick={() => addToCart(p)} className="bg-amber-600 text-white p-2 rounded-xl hover:bg-amber-700 transition"><Plus className="w-5 h-5" /></button>
    </div>
  </div>
);

const App = () => {
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [theme, setTheme] = useState<'dark' | 'light'>('dark');
  const [currentPage, setCurrentPage] = useState('home');
  const [cart, setCart] = useState<any[]>([]);
  const [filter, setFilter] = useState('all');

  const curT = t[lang];

  useEffect(() => {
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = lang;
  }, [lang]);

  const addToCart = (product: any) => {
    setCart(prev => {
      const exists = prev.find(item => item.id === product.id);
      if (exists) return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { ...product, quantity: 1 }];
    });
  };

  const updateQty = (id: number, delta: number) => {
    setCart(prev => prev.map(item => item.id === id ? { ...item, quantity: Math.max(1, item.quantity + delta) } : item));
  };

  const cartStats = useMemo(() => ({
    total: cart.reduce((s, i) => s + (i.price * i.quantity), 0),
    count: cart.reduce((s, i) => s + i.quantity, 0)
  }), [cart]);

  const Navbar = () => (
    <nav className={`h-20 border-b ${theme === 'dark' ? 'border-zinc-800/50 bg-zinc-950/60' : 'border-zinc-200 bg-white/60'} backdrop-blur-xl sticky top-0 z-50 flex items-center justify-between px-4 md:px-10 transition-colors duration-500`}>
      <div className="flex items-center gap-4 md:gap-6">
        <div className="relative cursor-pointer group" onClick={() => setCurrentPage('cart')}>
          <ShoppingCart className={`w-6 h-6 transition ${theme === 'dark' ? 'text-white hover:text-amber-500' : 'text-zinc-900 hover:text-amber-600'}`} />
          {cartStats.count > 0 && (
            <span className="absolute -top-2 -right-2 bg-amber-600 text-[10px] font-bold rounded-full w-5 h-5 flex items-center justify-center border-2 border-zinc-950 text-white">
              {cartStats.count}
            </span>
          )}
        </div>
        <button onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')} className={`p-2 rounded-full transition ${theme === 'dark' ? 'text-zinc-400 hover:bg-zinc-800' : 'text-zinc-600 hover:bg-zinc-100'}`}>
          {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
        <button onClick={() => setLang(lang === 'ar' ? 'en' : 'ar')} className={`flex items-center gap-1 text-xs font-bold transition ${theme === 'dark' ? 'text-zinc-400 hover:text-white' : 'text-zinc-600 hover:text-zinc-900'}`}>
          <Globe className="w-4 h-4" /> {lang === 'ar' ? 'EN' : 'العربية'}
        </button>
      </div>

      <div className="hidden md:flex gap-8 items-center font-medium">
        {['about', 'shop', 'home'].map(page => (
          <button 
            key={page} 
            onClick={() => setCurrentPage(page)} 
            className={`text-sm transition ${currentPage === page ? 'text-amber-500 border-b-2 border-amber-500 pb-1' : (theme === 'dark' ? 'text-zinc-400 hover:text-white' : 'text-zinc-600 hover:text-zinc-900')}`}
          >
            {curT.nav[page as keyof typeof curT.nav]}
          </button>
        ))}
      </div>

      <div onClick={() => setCurrentPage('home')} className="flex items-center cursor-pointer group">
        <div className={`p-1.5 rounded-2xl transition-all duration-500 group-hover:scale-105 ${theme === 'dark' ? 'bg-zinc-800/50' : 'bg-zinc-100'}`}>
          <img 
            src="https://cdn.salla.sa/RvpeX/03oRQT0iHt5eTNGQ4w9KIfYCaX55c283EHdYoUBk.png" 
            alt="Curve Coffee Logo" 
            className={`h-10 w-10 md:h-12 md:w-12 object-contain transition-all duration-500 ${theme === 'dark' ? 'invert brightness-0' : 'brightness-0 opacity-80 group-hover:opacity-100'}`}
          />
        </div>
      </div>
    </nav>
  );

  return (
    <div className={`min-h-screen font-sans transition-colors duration-500 ${theme === 'dark' ? 'bg-mesh-dark text-white' : 'bg-mesh-light text-zinc-900'}`}>
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 md:px-10 pb-20">
        <AnimatePresence mode="wait">
          {currentPage === 'home' && (
            <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <header className="h-[65vh] flex items-center justify-start text-start relative overflow-hidden">
                <div className="z-10 max-w-2xl">
                  <span className="inline-block bg-amber-600/10 text-amber-500 px-4 py-1 rounded-full text-xs font-bold mb-4 border border-amber-600/20">{curT.subtitle}</span>
                  <h1 className="text-5xl md:text-7xl font-black mb-4 leading-tight">{curT.heroTitle}<br/><span className="text-amber-500 italic font-serif">{curT.heroItalic}</span></h1>
                  <p className={`text-sm md:text-base leading-relaxed mb-8 font-light ${theme === 'dark' ? 'text-zinc-400' : 'text-zinc-600'}`}>{curT.heroDesc}</p>
                  <div className="flex gap-4">
                    <button onClick={() => setCurrentPage('shop')} className="bg-amber-600 text-white px-10 py-3 rounded-full text-sm font-bold shadow-lg shadow-amber-600/20 hover:bg-amber-700 transition">{curT.shopNow}</button>
                    <button onClick={() => setCurrentPage('about')} className={`px-10 py-3 rounded-full text-sm font-medium transition ${theme === 'dark' ? 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800' : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200'}`}>{curT.ourStory}</button>
                  </div>
                </div>
                <div className="absolute right-0 top-1/2 -translate-y-1/2 w-64 h-64 md:w-96 md:h-96 bg-amber-600/10 rounded-full blur-3xl pointer-events-none" />
              </header>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 my-20">
                {curT.features.map((f, i) => (
                  <motion.div 
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.1 }}
                    key={i} 
                    className={`p-8 rounded-3xl border transition-all ${theme === 'dark' ? 'bg-zinc-900/30 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}
                  >
                    <div className="bg-amber-600/10 w-12 h-12 rounded-full flex items-center justify-center mb-4 text-amber-500">
                      {i === 0 ? <Award className="w-6 h-6" /> : i === 1 ? <Truck className="w-6 h-6" /> : <ShieldCheck className="w-6 h-6" />}
                    </div>
                    <h4 className="font-bold text-lg mb-2">{f.title}</h4>
                    <p className={`text-sm leading-relaxed ${theme === 'dark' ? 'text-zinc-400' : 'text-zinc-600'}`}>{f.desc}</p>
                  </motion.div>
                ))}
              </div>

              <div className="flex justify-between items-end mb-12">
                <div>
                  <h2 className="text-4xl font-black mb-2">{curT.selectedCrops}</h2>
                  <div className="w-20 h-1 bg-amber-600 rounded-full" />
                </div>
                <button onClick={() => setCurrentPage('shop')} className="text-amber-500 hover:underline font-bold">{curT.viewAll}</button>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 mb-20">
                {PRODUCTS.slice(0, 3).map(p => (
                  <ProductCard key={p.id} p={p} lang={lang} theme={theme} currency={curT.currency} addToCart={addToCart} />
                ))}
              </div>
            </motion.div>
          )}

          {currentPage === 'shop' && (
            <motion.div key="shop" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="py-10">
              <h2 className="text-5xl font-black text-center mb-10">{curT.store}</h2>
            <div className="flex justify-center gap-3 mb-16 overflow-x-auto pb-4 no-scrollbar">
                {['all', 'crops', 'portable', 'tools'].map(cat => (
                  <button key={cat} onClick={() => setFilter(cat)} className={`whitespace-nowrap px-6 py-2 rounded-full text-sm font-bold transition ${filter === cat ? 'bg-amber-600 text-white shadow-lg shadow-amber-600/20' : (theme === 'dark' ? 'bg-zinc-900 text-zinc-400 hover:bg-zinc-800' : 'bg-zinc-100 text-zinc-600 hover:bg-zinc-200')}`}>
                    {curT[cat as keyof typeof curT] as string}
                  </button>
                ))}
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
                {PRODUCTS.filter(p => filter === 'all' || (filter === 'crops' && p.category.en === 'Crops') || (filter === 'tools' && p.category.en === 'Tools') || (filter === 'portable' && p.category.en === 'Portable Filters')).map(p => (
                  <ProductCard key={p.id} p={p} lang={lang} theme={theme} currency={curT.currency} addToCart={addToCart} />
                ))}
              </div>
            </motion.div>
          )}

          {currentPage === 'about' && (
            <motion.div key="about" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 1.05 }} className="py-24 max-w-5xl mx-auto">
              <div className="grid md:grid-cols-2 gap-16 items-center">
                <div className="relative">
                  <img src="https://images.unsplash.com/photo-1511537190424-bbbab87ac5eb?auto=format&fit=crop&q=80&w=800" className="rounded-3xl shadow-2xl relative z-10" alt="" />
                  <div className="absolute -bottom-6 -left-6 w-64 h-64 bg-amber-600/20 rounded-full blur-3xl" />
                </div>
                <div>
                  <h2 className="text-5xl font-black mb-8 leading-tight">{curT.aboutTitle.split(' ').slice(0, -1).join(' ')} <span className="text-amber-500 underline decoration-amber-500/20">{curT.aboutTitle.split(' ').pop()}</span></h2>
                  <p className={`text-lg leading-loose mb-10 font-light ${theme === 'dark' ? 'text-zinc-400' : 'text-zinc-600'}`}>{curT.aboutDesc}</p>
                  <div className="space-y-6">
                    <div className={`p-6 rounded-2xl border-l-4 border-amber-600 ${theme === 'dark' ? 'bg-zinc-900/50' : 'bg-zinc-50'}`}>
                      <h4 className="font-bold text-xl mb-1">{curT.missionTitle}</h4>
                      <p className="text-sm opacity-70">{curT.missionDesc}</p>
                    </div>
                    <div className={`p-6 rounded-2xl border-l-4 border-zinc-700 ${theme === 'dark' ? 'bg-zinc-900/50' : 'bg-zinc-50'}`}>
                      <h4 className="font-bold text-xl mb-1">{curT.visionTitle}</h4>
                      <p className="text-sm opacity-70">{curT.visionDesc}</p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {currentPage === 'cart' && (
            <motion.div key="cart" className="py-10 max-w-3xl mx-auto">
              <h2 className="text-3xl font-black mb-10">{curT.cartTitle}</h2>
              {cart.length === 0 ? (
                <div className={`text-center py-20 rounded-3xl border border-dashed ${theme === 'dark' ? 'bg-zinc-900/50 border-zinc-800' : 'bg-zinc-50 border-zinc-200'}`}>
                  <p className="text-zinc-500 mb-6">{curT.emptyCart}</p>
                  <button onClick={() => setCurrentPage('shop')} className="bg-amber-600 text-white px-8 py-2 rounded-full text-sm font-bold">{curT.continueShopping}</button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map(item => (
                    <div key={item.id} className={`flex items-center gap-4 p-4 rounded-2xl border ${theme === 'dark' ? 'bg-zinc-900/80 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                      <img src={item.image} className="w-16 h-16 object-cover rounded-xl" alt="" />
                      <div className="flex-grow">
                        <h4 className="font-bold">{item.name[lang]}</h4>
                        <p className="text-amber-500 text-sm">{item.price} {curT.currency}</p>
                      </div>
                      <div className="flex items-center gap-3">
                        <button onClick={() => updateQty(item.id, -1)} className="p-1 hover:text-amber-500"><Minus className="w-4 h-4"/></button>
                        <span className="w-6 text-center">{item.quantity}</span>
                        <button onClick={() => updateQty(item.id, 1)} className="p-1 hover:text-amber-500"><Plus className="w-4 h-4"/></button>
                      </div>
                    </div>
                  ))}
                  <div className={`mt-10 p-8 rounded-3xl border ${theme === 'dark' ? 'bg-zinc-900 border-zinc-800' : 'bg-zinc-50 border-zinc-200'}`}>
                    <div className="flex justify-between mb-4 text-sm"><span className="text-zinc-500">{curT.subtotal}</span><span>{cartStats.total} {curT.currency}</span></div>
                    <div className="flex justify-between mb-4 text-sm"><span className="text-zinc-500">{curT.shipping}</span><span>25 {curT.currency}</span></div>
                    <div className="flex justify-between text-xl font-black border-t pt-6"><span className="text-amber-500">{cartStats.total + 25} {curT.currency}</span><span>{curT.total}</span></div>
                    <button className="w-full bg-amber-600 text-white py-4 rounded-2xl font-black mt-8 hover:bg-amber-700 transition shadow-lg shadow-amber-600/20">{curT.checkout}</button>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className={`h-20 border-t ${theme === 'dark' ? 'bg-black/40 border-zinc-900' : 'bg-white/80 border-zinc-100'} backdrop-blur-md flex items-center justify-between px-4 md:px-10 text-[10px] text-zinc-500 uppercase tracking-widest`}>
        <div>© 2024 CURVE COFFEE</div>
        <div className="flex gap-6 items-center">
          <span className="hidden md:inline">{curT.location}</span>
          <div className="flex gap-4">
            <Instagram className="w-4 h-4 cursor-pointer hover:text-amber-500 transition" />
            <Twitter className="w-4 h-4 cursor-pointer hover:text-amber-500 transition" />
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
